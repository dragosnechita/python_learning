from distutils.core import setup

setup (
name = 'nested_list',
version = '1.0.0',
py_modules= ['nested_list'],
author= 'Dragos Nechita',
author_email= 'hfpython@headfirstlabs.com',
url = 'http://www.headfirstlabs.com',
description = 'A simple printer of nested lists',
)
